#!/bin/bash
service nginx start
/usr/local/tomcat/bin/startup.sh
